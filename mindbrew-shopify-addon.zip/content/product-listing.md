Title: MindBrew Mushroom Coffee Fusion — Lion's Mane + Chaga (16 oz)
Subtitle: Real coffee taste. Clean, focused energy.
Short bullets:
• 100% Arabica coffee with 1200 mg mushroom extracts per serving
• Half the caffeine—no jitters, no crash
• Smooth, nutty flavor; roasts in the USA
• Brew it your way: drip, pour-over, or French press
Long description (HTML-ready):
<p>Meet MindBrew: a functional coffee that actually tastes like coffee. We blend premium 100% Arabica beans with Lion's Mane and Chaga extracts for calm, focused energy without the notorious caffeine crash.</p>
<ul>
  <li><strong>Clarity & Focus:</strong> Lion's Mane is prized for supporting cognitive performance.</li>
  <li><strong>Calm Energy:</strong> Chaga complements coffee's lift for a smoother feel.</li>
  <li><strong>Flavor First:</strong> Small-batch roasted Arabica with smooth, nutty notes.</li>
</ul>
<p>How to brew: Use 1–2 tbsp per 8 oz water. Works with drip, pour-over, and French press.</p>
<p>Allergen info: Vegan and gluten-free. About 45 mg caffeine per 8 oz cup.</p>
