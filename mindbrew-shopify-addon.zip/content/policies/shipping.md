We process orders in 1–2 business days. US shipping typically arrives within 3–7 business days depending on the method selected at checkout. You’ll receive tracking via email.
